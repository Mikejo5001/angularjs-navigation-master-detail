﻿(function () {

    window.isVHPartiallySupported = false;

})();