/** Automatically generated file. DO NOT MODIFY */
package io.cordova.myappc188adf0b430465688ed5dc913c4d5fd;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}