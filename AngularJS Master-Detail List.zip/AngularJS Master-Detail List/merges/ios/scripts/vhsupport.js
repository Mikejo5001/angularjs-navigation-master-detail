﻿(function () {

    window.isVHPartiallySupported = true;

})();